﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BaseProvider;

namespace VbJobProvider
{
    public class VbJob : IBaseJob
    {
        public Queue<string> privateQueue { get; set; }

        public void DoJob(object jobPatameter)
        {

        }

        public string DoTempJob(object jobPatameter)
        {
            return jobPatameter.ToString() + " This is returned by vb job.";
        }
    }
}
