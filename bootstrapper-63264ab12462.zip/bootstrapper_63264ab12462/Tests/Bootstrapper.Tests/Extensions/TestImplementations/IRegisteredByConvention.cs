﻿namespace Bootstrap.Tests.Extensions.TestImplementations
{
    public interface IRegisteredByConvention
    {
        void DoSomething();
    }
}
