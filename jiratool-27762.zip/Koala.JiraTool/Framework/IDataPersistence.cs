﻿using System;
using Koala.Framework;

namespace Framework
{
    public interface IDataPersistence : ISingletonDependency
    {
        void Save(string key, object data);

        void Save(object data);

        object Get(string key, Type type);

        T Get<T>(string key) where T : class, new();

        object Get(Type type);

        T Get<T>() where T : class, new();
    }
}