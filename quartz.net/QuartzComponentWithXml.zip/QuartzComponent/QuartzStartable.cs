using System;
using System.Collections.Generic;
using System.Text;

using Castle.Core;
using Quartz.Impl;
using Quartz;
using Common.Logging;
using System.Threading;
using System.IO;
using Quartz.Xml;
using System.Collections;

namespace QuartzComponent
{
    [Transient]
    public class QuartzStartable : IStartable
    {
        private ISchedulerFactory _schedFactory;
        private JobSchedulingDataProcessor processor;

        private static ILog log = LogManager.GetLogger(typeof(QuartzStartable));

        public QuartzStartable(ISchedulerFactory schedFactory)
        {
            _schedFactory = schedFactory;
            processor = new JobSchedulingDataProcessor(true, true);
        }

        public void Start()
        {
            log.Info("Starting service");
            IScheduler sched = _schedFactory.GetScheduler();

            //log.Info("------- Scheduling Jobs ----------------");

            //// jobs can be scheduled before sched.start() has been called

            //// get a "nice round" time a few seconds in the future...
            //DateTime ts = TriggerUtils.GetNextGivenSecondDate(null, 15);

            //// job1 will only fire once at date/time "ts"
            //JobDetail job = new JobDetail("job1", "group1", typeof(SimpleQuartzJob));
            //SimpleTrigger trigger = new SimpleTrigger("trigger1", "group1");
            //// set its start up time
            //trigger.StartTimeUtc = ts;
            //// set the interval, how often the job should run (10 seconds here) 
            //trigger.RepeatInterval = 10000;
            //// set the number of execution of this job, set to 10 times. 
            //// It will run 10 time and exhaust.
            //trigger.RepeatCount = 100;


            //// schedule it to run!
            //DateTime ft = sched.ScheduleJob(job, trigger);
            //log.Info(string.Format("{0} will run at: {1} and repeat: {2} times, every {3} seconds",
            //    job.FullName, ft.ToString("r"), trigger.RepeatCount, (trigger.RepeatInterval / 1000)));
            //log.Info("------- Waiting five minutes... ------------");

            //sched.Start();
            Stream s = ReadJobXmlFromEmbeddedResource("MinimalConfiguration.xml");
            processor.ProcessStream(s, null);
            processor.ScheduleJobs(new Hashtable(), sched, false);
            sched.Start();
            try
            {
                // wait five minutes to show jobs
                Thread.Sleep(300 * 1000);
                // executing...
            }
            catch (ThreadInterruptedException)
            {
            }


        }

        private static Stream ReadJobXmlFromEmbeddedResource(string resourceName)
        {
            string fullName = "QuartzComponent." + resourceName;
            return new StreamReader(typeof(QuartzStartable).Assembly.GetManifestResourceStream(fullName)).BaseStream;
        }

        public void Stop()
        {
            log.Info("Stopping service");
            try
            {
                IScheduler scheduler = _schedFactory.GetScheduler();
                scheduler.Shutdown(true);
            }
            catch (SchedulerException se)
            {
                log.Error("Cannot shutdown scheduler.", se);
            }

        }
    }
}
