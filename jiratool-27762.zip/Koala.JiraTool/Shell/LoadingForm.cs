﻿using Koala.Framework.Environment;
using System;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Shell
{
    internal partial class LoadingForm : Form
    {
        public static NotifyIcon NotifyIcon;

        public LoadingForm()
        {
            InitializeComponent();
            NotifyIcon = notifyIcon;
        }

        private void LoadingForm_Load(object sender, EventArgs e)
        {
            //异步初始化主机。
            Task.Factory.StartNew(() =>
           {
               //创建主机。
               var host = Starter.CreateHost(typeof(Program).Assembly);
               host.Initialize += (s, ee) =>
               {
                   var shellContext = host.GetDefaultShellContext();
                   var mainForm = shellContext.Container.Resolve<MainForm>();
                   Invoke(new Action(() =>
                   {
                       mainForm.Show();
                       mainForm.FormClosed += (ss, eee) => Close();
                   }));
               };
               host.Start();
           }).ContinueWith(task =>
           {
               Invoke(new Action(() => Visible = false));
           });
        }
    }
}