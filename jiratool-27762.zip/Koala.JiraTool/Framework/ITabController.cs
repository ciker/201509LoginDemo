﻿using System;
using System.Windows.Forms;
using Koala.Framework;

namespace Framework
{
    public interface ITabController : IDependency
    {
        void OpenTab(TabPage tabPage, bool isClose = true);

        void OpenTab(string title, Action<TabPage> action, bool isClose = true);
    }
}