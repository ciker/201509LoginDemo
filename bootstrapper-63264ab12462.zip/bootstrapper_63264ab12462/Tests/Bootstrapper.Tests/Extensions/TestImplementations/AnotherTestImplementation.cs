﻿namespace Bootstrap.Tests.Extensions.TestImplementations
{
    public class AnotherTestImplementation: ITestInterface
    {
    }
}
