# Backbone.js with Google Maps demo

![Backbone.js with Google Maps demo](https://raw.github.com/iloire/backbonejs-googlemaps-demo/master/screenshots/backbonejs_google_maps01.png)

Don't expect anything fancy. Just a simple demo of how to use Backbone.js with Google Maps and some interaction with markers and views..

## Getting Started

Open index.html.

## Online demo in GitHub (gh-pages)

http://iloire.github.com/backbonejs-googlemaps-demo/

## Release History
### 0.1.0 Initial release

## License
Copyright (c) 2012 Iván Loire
Licensed under the MIT license.
