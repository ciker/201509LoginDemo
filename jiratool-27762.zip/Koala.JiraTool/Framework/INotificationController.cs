﻿using Koala.Framework;

namespace Framework
{
    public interface INotificationController : IDependency
    {
        void Message(string format, params object[] args);
    }
}