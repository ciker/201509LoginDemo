using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.DataAnnotations;
namespace ^DAL^
{
    [MetadataType(typeof(^ReplaceClassCode^Metadata))]
    public partial class ^ReplaceClassCode^ : IBaseEntity
    {
        ^CustomEntity^
        #region �Զ�������

        #endregion

    }
    public class ^ReplaceClassCode^Metadata
    {
^ReplaceAttribute^
    }


}
