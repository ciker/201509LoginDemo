﻿using System;
using System.Reflection;
using System.Windows.Forms;
using Plugin;
using System.Collections.Generic;

namespace MyApplication
{
    public partial class MainClass : Form
    {
        public MainClass()
        {
            InitializeComponent();
        }
        private void cmdOpen_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Plugin Files|*.dll";
            if (DialogResult.OK == ofd.ShowDialog())
            {
                Assembly a = Assembly.LoadFrom(ofd.FileName);
                foreach (Type t in a.GetTypes())
                {
                    if (t.GetInterface("IMyFunction") != null)
                    {
                        try
                        {
                            IMyFunction pluginclass = Activator.CreateInstance(t) as IMyFunction;
                            pluginclass.doSomething();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.ToString());
                        }
                    }
                }

            }
        }
    }
}
