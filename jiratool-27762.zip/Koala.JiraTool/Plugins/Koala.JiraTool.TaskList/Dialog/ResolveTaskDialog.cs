﻿using Framework;
using Framework.Models;
using Koala.Framework;
using System;
using System.Windows.Forms;

namespace Koala.JiraTool.TaskList.Dialog
{
    public partial class ResolveTaskDialog : Form, ITransientDependency
    {
        private TaskInfo _taskInfo;
        private readonly ITaskController _taskController;

        public ResolveTaskDialog(ITaskController taskController)
        {
            _taskController = taskController;
            InitializeComponent();
            cmbResolveResult.SelectedIndex = 0;
        }

        public void LoadDialog(TaskInfo taskInfo)
        {
            _taskInfo = taskInfo;
            var date = _taskInfo.UpdateDateTime;
            if (date.HasValue)
            {
                txtStartTime.Text = date.Value.ToString("yyyy-MM-dd H:mm:ss");
            }
        }

        private void tsbSave_Click(object sender, System.EventArgs e)
        {
            try
            {
                var model = new ResolveTaskInfo
                {
                    ConsumeTime = txtConsumeTime.Text,
                    Environment = txtEnvironment.Text,
                    Remark = txtRemark.Text,
                    StartTime = txtStartTime.Text,
                    TaskId = _taskInfo.Id
                };
                switch (cmbResolveResult.SelectedText)
                {
                    case "未解决":
                        model.ResolveResult = "2";
                        break;

                    case "已解决":
                        model.ResolveResult = "1";
                        break;

                    case "未分配":
                        model.ResolveResult = "6";
                        break;

                    case "问题重复":
                        model.ResolveResult = "3";
                        break;

                    case "部分解决":
                        model.ResolveResult = "4";
                        break;

                    case "信息不足":
                        model.ResolveResult = "5";
                        break;
                }
                _taskController.ResolveTask(model);
                Close();
            }
            catch (Exception exception)
            {
                MessageBox.Show("发生了错误：" + exception.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}