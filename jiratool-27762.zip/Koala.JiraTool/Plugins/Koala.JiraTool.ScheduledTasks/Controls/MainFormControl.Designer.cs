﻿
using Koala.Framework;

namespace Koala.JiraTool.ScheduledTasks.Controls
{
    partial class MainFormControl
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        private System.Windows.Forms.ToolStrip toolStrip;
        private System.Windows.Forms.ToolStripButton tsbStart;
        private System.Windows.Forms.ToolStripButton tsbStop;
        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tpStopTask;
        private System.Windows.Forms.TabPage tpStartTask;

        private System.Windows.Forms.ToolStripButton tsbAllStart;
        private System.Windows.Forms.ToolStripButton tsbAllStop;

        private ScheduledItemControl sicStop;
        private ScheduledItemControl sicStart;
        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainFormControl));
            this.toolStrip = new System.Windows.Forms.ToolStrip();
            this.tsbStart = new System.Windows.Forms.ToolStripButton();
            this.tsbStop = new System.Windows.Forms.ToolStripButton();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tpStopTask = new System.Windows.Forms.TabPage();
            this.sicStop = new ScheduledItemControl();
            this.tpStartTask = new System.Windows.Forms.TabPage();
            this.sicStart = new ScheduledItemControl();
            this.tsbAllStart = new System.Windows.Forms.ToolStripButton();
            this.tsbAllStop = new System.Windows.Forms.ToolStripButton();
            this.toolStrip.SuspendLayout();
            this.tabControl.SuspendLayout();
            this.tpStopTask.SuspendLayout();
            this.tpStartTask.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip
            // 
            this.toolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbStart,
            this.tsbStop,
            this.tsbAllStart,
            this.tsbAllStop});
            this.toolStrip.Location = new System.Drawing.Point(0, 0);
            this.toolStrip.Name = "toolStrip";
            this.toolStrip.Size = new System.Drawing.Size(737, 25);
            this.toolStrip.TabIndex = 0;
            this.toolStrip.Text = "toolStrip1";
            // 
            // tsbStart
            // 
            this.tsbStart.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbStart.Image = ((System.Drawing.Image)(resources.GetObject("tsbStart.Image")));
            this.tsbStart.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbStart.Name = "tsbStart";
            this.tsbStart.Size = new System.Drawing.Size(35, 22);
            this.tsbStart.Text = "启用";
            this.tsbStart.Click += new System.EventHandler(this.tsbStart_Click);
            // 
            // tsbStop
            // 
            this.tsbStop.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbStop.Image = ((System.Drawing.Image)(resources.GetObject("tsbStop.Image")));
            this.tsbStop.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbStop.Name = "tsbStop";
            this.tsbStop.Size = new System.Drawing.Size(35, 22);
            this.tsbStop.Text = "停用";
            this.tsbStop.Click += new System.EventHandler(this.tsbStop_Click);
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tpStopTask);
            this.tabControl.Controls.Add(this.tpStartTask);
            this.tabControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl.Location = new System.Drawing.Point(0, 25);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(737, 433);
            this.tabControl.TabIndex = 1;
            // 
            // tpStopTask
            // 
            this.tpStopTask.Controls.Add(this.sicStop);
            this.tpStopTask.Location = new System.Drawing.Point(4, 22);
            this.tpStopTask.Name = "tpStopTask";
            this.tpStopTask.Padding = new System.Windows.Forms.Padding(3);
            this.tpStopTask.Size = new System.Drawing.Size(729, 407);
            this.tpStopTask.TabIndex = 0;
            this.tpStopTask.Text = "停止进行任务";
            this.tpStopTask.UseVisualStyleBackColor = true;
            // 
            // sicStop
            // 
            this.sicStop.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sicStop.Location = new System.Drawing.Point(3, 3);
            this.sicStop.Name = "sicStop";
            this.sicStop.Size = new System.Drawing.Size(723, 401);
            this.sicStop.TabIndex = 0;
            // 
            // tpStartTask
            // 
            this.tpStartTask.Controls.Add(this.sicStart);
            this.tpStartTask.Location = new System.Drawing.Point(4, 22);
            this.tpStartTask.Name = "tpStartTask";
            this.tpStartTask.Padding = new System.Windows.Forms.Padding(3);
            this.tpStartTask.Size = new System.Drawing.Size(729, 407);
            this.tpStartTask.TabIndex = 1;
            this.tpStartTask.Text = "开始进行任务";
            this.tpStartTask.UseVisualStyleBackColor = true;
            // 
            // sicStart
            // 
            this.sicStart.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sicStart.Location = new System.Drawing.Point(3, 3);
            this.sicStart.Name = "sicStart";
            this.sicStart.Size = new System.Drawing.Size(723, 401);
            this.sicStart.TabIndex = 0;
            // 
            // tsbAllStart
            // 
            this.tsbAllStart.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbAllStart.Image = ((System.Drawing.Image)(resources.GetObject("tsbAllStart.Image")));
            this.tsbAllStart.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbAllStart.Name = "tsbAllStart";
            this.tsbAllStart.Size = new System.Drawing.Size(59, 22);
            this.tsbAllStart.Text = "全部启用";
            this.tsbAllStart.Click += new System.EventHandler(this.tsbAllStart_Click);
            // 
            // tsbAllStop
            // 
            this.tsbAllStop.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbAllStop.Image = ((System.Drawing.Image)(resources.GetObject("tsbAllStop.Image")));
            this.tsbAllStop.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbAllStop.Name = "tsbAllStop";
            this.tsbAllStop.Size = new System.Drawing.Size(59, 22);
            this.tsbAllStop.Text = "全部停用";
            this.tsbAllStop.Click += new System.EventHandler(this.tsbAllStop_Click);
            // 
            // MainFormControl
            // 
            this.Controls.Add(this.tabControl);
            this.Controls.Add(this.toolStrip);
            this.Name = "MainFormControl";
            this.Size = new System.Drawing.Size(737, 458);
            this.toolStrip.ResumeLayout(false);
            this.toolStrip.PerformLayout();
            this.tabControl.ResumeLayout(false);
            this.tpStopTask.ResumeLayout(false);
            this.tpStartTask.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent(IContainer container)
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainFormControl));
            this.toolStrip = new System.Windows.Forms.ToolStrip();
            this.tsbStart = new System.Windows.Forms.ToolStripButton();
            this.tsbStop = new System.Windows.Forms.ToolStripButton();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tpStopTask = new System.Windows.Forms.TabPage();
            this.sicStop = container.Resolve<ScheduledItemControl>();
            this.tpStartTask = new System.Windows.Forms.TabPage();
            this.sicStart = container.Resolve<ScheduledItemControl>();
            this.tsbAllStart = new System.Windows.Forms.ToolStripButton();
            this.tsbAllStop = new System.Windows.Forms.ToolStripButton();
            this.toolStrip.SuspendLayout();
            this.tabControl.SuspendLayout();
            this.tpStopTask.SuspendLayout();
            this.tpStartTask.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip
            // 
            this.toolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbStart,
            this.tsbStop,
            this.tsbAllStart,
            this.tsbAllStop});
            this.toolStrip.Location = new System.Drawing.Point(0, 0);
            this.toolStrip.Name = "toolStrip";
            this.toolStrip.Size = new System.Drawing.Size(737, 25);
            this.toolStrip.TabIndex = 0;
            this.toolStrip.Text = "toolStrip1";
            // 
            // tsbStart
            // 
            this.tsbStart.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbStart.Image = ((System.Drawing.Image)(resources.GetObject("tsbStart.Image")));
            this.tsbStart.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbStart.Name = "tsbStart";
            this.tsbStart.Size = new System.Drawing.Size(35, 22);
            this.tsbStart.Text = "启用";
            this.tsbStart.Click += new System.EventHandler(this.tsbStart_Click);
            // 
            // tsbStop
            // 
            this.tsbStop.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbStop.Image = ((System.Drawing.Image)(resources.GetObject("tsbStop.Image")));
            this.tsbStop.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbStop.Name = "tsbStop";
            this.tsbStop.Size = new System.Drawing.Size(35, 22);
            this.tsbStop.Text = "停用";
            this.tsbStop.Click += new System.EventHandler(this.tsbStop_Click);
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tpStopTask);
            this.tabControl.Controls.Add(this.tpStartTask);
            this.tabControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl.Location = new System.Drawing.Point(0, 25);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(737, 433);
            this.tabControl.TabIndex = 1;
            // 
            // tpStopTask
            // 
            this.tpStopTask.Controls.Add(this.sicStop);
            this.tpStopTask.Location = new System.Drawing.Point(4, 22);
            this.tpStopTask.Name = "tpStopTask";
            this.tpStopTask.Padding = new System.Windows.Forms.Padding(3);
            this.tpStopTask.Size = new System.Drawing.Size(729, 407);
            this.tpStopTask.TabIndex = 0;
            this.tpStopTask.Text = "停止进行任务";
            this.tpStopTask.UseVisualStyleBackColor = true;
            // 
            // sicStop
            // 
            this.sicStop.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sicStop.Location = new System.Drawing.Point(3, 3);
            this.sicStop.Name = "sicStop";
            this.sicStop.Size = new System.Drawing.Size(723, 401);
            this.sicStop.TabIndex = 0;
            // 
            // tpStartTask
            // 
            this.tpStartTask.Controls.Add(this.sicStart);
            this.tpStartTask.Location = new System.Drawing.Point(4, 22);
            this.tpStartTask.Name = "tpStartTask";
            this.tpStartTask.Padding = new System.Windows.Forms.Padding(3);
            this.tpStartTask.Size = new System.Drawing.Size(729, 407);
            this.tpStartTask.TabIndex = 1;
            this.tpStartTask.Text = "开始进行任务";
            this.tpStartTask.UseVisualStyleBackColor = true;
            // 
            // sicStart
            // 
            this.sicStart.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sicStart.Location = new System.Drawing.Point(3, 3);
            this.sicStart.Name = "sicStart";
            this.sicStart.Size = new System.Drawing.Size(723, 401);
            this.sicStart.TabIndex = 0;
            // 
            // tsbAllStart
            // 
            this.tsbAllStart.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbAllStart.Image = ((System.Drawing.Image)(resources.GetObject("tsbAllStart.Image")));
            this.tsbAllStart.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbAllStart.Name = "tsbAllStart";
            this.tsbAllStart.Size = new System.Drawing.Size(59, 22);
            this.tsbAllStart.Text = "全部启用";
            this.tsbAllStart.Click += new System.EventHandler(this.tsbAllStart_Click);
            // 
            // tsbAllStop
            // 
            this.tsbAllStop.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbAllStop.Image = ((System.Drawing.Image)(resources.GetObject("tsbAllStop.Image")));
            this.tsbAllStop.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbAllStop.Name = "tsbAllStop";
            this.tsbAllStop.Size = new System.Drawing.Size(59, 22);
            this.tsbAllStop.Text = "全部停用";
            this.tsbAllStop.Click += new System.EventHandler(this.tsbAllStop_Click);
            // 
            // MainFormControl
            // 
            this.Controls.Add(this.tabControl);
            this.Controls.Add(this.toolStrip);
            this.Name = "MainFormControl";
            this.Size = new System.Drawing.Size(737, 458);
            this.toolStrip.ResumeLayout(false);
            this.toolStrip.PerformLayout();
            this.tabControl.ResumeLayout(false);
            this.tpStopTask.ResumeLayout(false);
            this.tpStartTask.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }


        #endregion

    }
}
