﻿namespace Bootstrap.Tests.Extensions.TestImplementations
{
    public class TestImplementation: ITestInterface {}
}
