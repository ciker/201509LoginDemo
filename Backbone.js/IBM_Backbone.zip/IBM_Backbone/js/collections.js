App.Collections.Teams = Backbone.Collection.extend({
    model : App.Models.Team
});
