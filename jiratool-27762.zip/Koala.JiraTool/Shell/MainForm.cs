﻿using Framework;
using Framework.Models;
using Koala.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace Shell
{
    public partial class MainForm : Form, IDependency
    {
        #region Field

        public static MenuStrip MenuStrip;
        public static TabControl TabControl;
        public static ToolStripItem ToolStripItem;
        public static NotifyIcon NotifyIcon;
        public static ContextMenuStrip TabContextMenuStrip;
        private readonly IEnumerable<IMenuProvider> _menuProviders;
        private readonly IMenuController _menuController;
        private readonly IEnumerable<IMainFormEvent> _mainFormEvents;
        private readonly List<MenuInfo> _menuInfos = new List<MenuInfo>();

        #endregion Field

        #region Constructor

        public MainForm()
        {
            InitializeComponent();
        }

        public MainForm(IEnumerable<IMenuProvider> menuProviders, IMenuController menuController, IEnumerable<IMainFormEvent> mainFormEvents)
        {
            _menuProviders = menuProviders;
            _menuController = menuController;
            _mainFormEvents = mainFormEvents;
            InitializeComponent();
            MenuStrip = menuStrip;
            TabControl = tabControl;
            ToolStripItem = tsslMessage;
            NotifyIcon = LoadingForm.NotifyIcon;
            TabContextMenuStrip = cmsTab;
            Load += MainForm_Load;
            NotifyIcon.BalloonTipClicked += notifyIcon_BalloonTipClicked;
            NotifyIcon.MouseClick += notifyIcon_MouseClick;
            NotifyIcon.ContextMenuStrip = cmsNotify;
            NotifyIcon.Text = Text;
        }

        #endregion Constructor

        #region Event

        private void MainForm_Load(object sender, EventArgs e)
        {
            NotifyIcon.Icon = Icon;
            LoadMenus();
            foreach (var mainFormEvent in _mainFormEvents)
                mainFormEvent.LoadOk();
        }

        /// <summary>
        /// 关闭TabPage。
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tsmiCloseTab_Click(object sender, EventArgs e)
        {
            var tab = tabControl.SelectedTab;
            if (tab == null)
                return;
            var menu = _menuInfos.FirstOrDefault(model => model.Text == tab.Text);

            #region Is Allow Close

            if (menu != null && !menu.IsClose)
                return;

            var tag = tab.Tag;
            var result = true;
            if (tag != null)
            {
                bool.TryParse(tag.ToString(), out result);
                if (!result)
                {
                    return;
                }
            }
            /*
                        var tag = tab.Tag;
                        var result = true;
                        if (tag != null)
                            bool.TryParse(tag.ToString(), out result);
                        if (menu == null && !menu.IsClose || !result)*/

            #endregion Is Allow Close

            if (menu == null)
                return;

            tabControl.TabPages.Remove(tab);
        }

        private void notifyIcon_BalloonTipClicked(object sender, EventArgs e)
        {
            NotifyIcon.Visible = false;
            TopMost = true;
            WindowState = FormWindowState.Normal;
            ShowInTaskbar = true;
            TopMost = false;
        }

        private void MainForm_Deactivate(object sender, EventArgs e)
        {
            if (WindowState != FormWindowState.Minimized) return;
            NotifyIcon.Visible = true;
            NotifyIcon.ShowBalloonTip(1000, "信息", "已被隐藏至通知栏，单击打开窗体。", ToolTipIcon.Info);
            ShowInTaskbar = false;
        }

        private void notifyIcon_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left) return;
            NotifyIcon.Visible = false;
            TopMost = true;
            WindowState = FormWindowState.Normal;
            ShowInTaskbar = true;
            TopMost = false;
        }

        private void tsmiExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        #endregion Event

        #region Private Method

        /// <summary>
        /// 加载菜单。
        /// </summary>
        private void LoadMenus()
        {
            _menuInfos.Clear();
            //收集菜单。
            foreach (var menuProvider in _menuProviders)
                menuProvider.GetMenuList(_menuInfos);

            //已经添加过的菜单名称。
            var cList = new List<string>();
            //筛选没有进行添加动作的菜单。
            foreach (var menuInfo in _menuInfos.Where(model => model != null).Where(menuInfo => !cList.Contains(menuInfo.Text) && !string.IsNullOrWhiteSpace(menuInfo.Text)))
            {
                //添加菜单。
                _menuController.AddMenu(menuInfo);
                cList.Add(menuInfo.Text);
            }
        }

        #endregion Private Method
    }
}