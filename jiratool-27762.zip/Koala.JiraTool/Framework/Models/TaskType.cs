﻿/*namespace Framework.Models
{
    /// <summary>
    /// 任务类型。
    /// </summary>
    public enum TaskType
    {
        /// <summary>
        /// 未知。
        /// </summary>
        Unknown,

        /// <summary>
        /// 描述。
        /// </summary>
        Description,

        /// <summary>
        /// 改进。
        /// </summary>
        Improve,

        /// <summary>
        /// 新任务。
        /// </summary>
        New,

        /// <summary>
        /// 新功能。
        /// </summary>
        Function,

        /// <summary>
        /// 子任务。
        /// </summary>
        Child
    }
}*/