﻿using System;
using System.Windows.Forms;

namespace Koala.JiraTool.TaskList.Dialog
{
    public partial class BrowserDialog : Form
    {
        public BrowserDialog(string title, string url)
        {
            InitializeComponent();
            Text = title;
            webBrowser.Url = new Uri(url);
        }
    }
}