Thanks for downloading this Castle Windsor package.
You can find full list of changes in changes.txt

Documentation:		- http://docs.castleproject.org/Windsor.MainPage.ashx
Discusssion group: 	- http://groups.google.com/group/castle-project-users
StackOverflow tags:	- castle-windsor, castle

Issue tracker: 		- http://issues.castleproject.org/dashboard
