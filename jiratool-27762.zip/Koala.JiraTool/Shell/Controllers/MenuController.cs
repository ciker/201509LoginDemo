﻿using Framework;
using Framework.Models;

namespace Shell.Controllers
{
    internal class MenuController : IMenuController
    {
        #region Implementation of IMenuController

        public void AddMenu(MenuInfo menuInfo)
        {
            var item = MainForm.MenuStrip.Items.Add(menuInfo.Text);
            item.Click += menuInfo.ClickEventHandler;
            if (menuInfo.ChildMenus == null) return;
            foreach (var childMenu in menuInfo.ChildMenus)
            {
                AddMenu(childMenu);
            }
        }

        #endregion Implementation of IMenuController
    }
}