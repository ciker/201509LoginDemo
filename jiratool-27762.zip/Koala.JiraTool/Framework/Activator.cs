﻿using Koala.Framework.Plugins;

namespace Framework
{
    internal class Activator : IPluginActivator
    {
        #region Implementation of IPluginActivator

        /// <summary>
        /// 启动插件。
        /// </summary>
        /// <param name="context">插件上下文。</param>
        public void Start(IPluginContext context)
        {
        }

        /// <summary>
        /// 停止插件。
        /// </summary>
        /// <param name="context">插件上下文。</param>
        public void Stop(IPluginContext context)
        {
        }

        #endregion Implementation of IPluginActivator
    }
}