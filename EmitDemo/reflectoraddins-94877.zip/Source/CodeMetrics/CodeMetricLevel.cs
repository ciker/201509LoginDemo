﻿namespace Reflector.CodeMetrics
{
	public enum CodeMetricLevel
    {
        Method,
        Type,
        Module
    }
}
