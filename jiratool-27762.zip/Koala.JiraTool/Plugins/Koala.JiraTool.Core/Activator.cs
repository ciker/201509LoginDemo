﻿using Framework;
using Koala.Framework.Plugins;
using System.Text;

namespace Koala.JiraTool.Core
{
    internal class Activator : IPluginActivator
    {
        #region Implementation of IPluginActivator

        /// <summary>
        /// 启动插件。
        /// </summary>
        /// <param name="context">插件上下文。</param>
        public void Start(IPluginContext context)
        {
            var serviceRegister = context.ServiceRegister;
            serviceRegister.RegisterInstance(new GlobalSettings
                {
                    RootUrl = "http://192.168.9.6:8080/",
                    LoginUrl = "http://192.168.9.6:8080/login.jsp",
                    StartTaskUrlFormat = "http://192.168.9.6:8080/secure/WorkflowUIDispatcher.jspa?id={0}&action=4&atl_token={1}",
                    StopTaskUrlFormat = "http://192.168.9.6:8080/secure/WorkflowUIDispatcher.jspa?id={0}&action=301&atl_token={1}",
                    ResolveTaskUrlFormat = "http://192.168.9.6:8080/secure/CommentAssignIssue.jspa?atl_token={0}",
                    SearchTaskUrlFormat = "http://192.168.9.6:8080/issues/?jql={0}",
                    TaskViewUrlFormat = "http://192.168.9.6:8080/browse/{0}",
                    Encoding = Encoding.UTF8
                });
            serviceRegister.Commit();
        }

        /// <summary>
        /// 停止插件。
        /// </summary>
        /// <param name="context">插件上下文。</param>
        public void Stop(IPluginContext context)
        {
        }

        #endregion Implementation of IPluginActivator
    }
}