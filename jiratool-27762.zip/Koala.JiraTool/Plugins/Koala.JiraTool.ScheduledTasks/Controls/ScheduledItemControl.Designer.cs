﻿namespace Koala.JiraTool.ScheduledTasks.Controls
{
    partial class ScheduledItemControl
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.taskListControl = new Koala.JiraTool.ScheduledTasks.Controls.TaskListControl();

            this.lblDescription = new System.Windows.Forms.Label();
            this.txtTime = new System.Windows.Forms.TextBox();
            this.lblEndTime = new System.Windows.Forms.Label();
            this.lblTime = new System.Windows.Forms.Label();
            this.cbAutoRun = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // ScheduledItemControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.cbAutoRun);
            this.Controls.Add(this.lblTime);
            this.Controls.Add(this.lblEndTime);
            this.Controls.Add(this.txtTime);
            this.Controls.Add(this.lblDescription);
            this.Controls.Add(this.taskListControl);
            this.Name = "ScheduledItemControl";
            this.Size = new System.Drawing.Size(751, 526);
            this.ResumeLayout(false);
            this.PerformLayout();
            // 
            // taskListControl
            // 
            this.taskListControl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.taskListControl.Location = new System.Drawing.Point(4, 49);
            this.taskListControl.Name = Name+"_taskListControl";
            this.taskListControl.Size = new System.Drawing.Size(747, 477);
            this.taskListControl.TabIndex = 0;
            // 
            // lblDescription
            // 
            this.lblDescription.AutoSize = true;
            this.lblDescription.Location = new System.Drawing.Point(3, 3);
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.Size = new System.Drawing.Size(101, 12);
            this.lblDescription.TabIndex = 1;
            this.lblDescription.Text = "在以下时间执行：";
            // 
            // txtTime
            // 
            this.txtTime.Location = new System.Drawing.Point(110, 0);
            this.txtTime.Name = "txtTime";
            this.txtTime.Size = new System.Drawing.Size(150, 21);
            this.txtTime.TabIndex = 2;
            // 
            // lblEndTime
            // 
            this.lblEndTime.AutoSize = true;
            this.lblEndTime.Location = new System.Drawing.Point(303, 3);
            this.lblEndTime.Name = "lblEndTime";
            this.lblEndTime.Size = new System.Drawing.Size(101, 12);
            this.lblEndTime.TabIndex = 3;
            this.lblEndTime.Text = "离下次执行还有：";
            // 
            // lblTime
            // 
            this.lblTime.AutoSize = true;
            this.lblTime.Location = new System.Drawing.Point(410, 3);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(0, 12);
            this.lblTime.TabIndex = 4;
            // 
            // cbAutoRun
            // 
            this.cbAutoRun.AutoSize = true;
            this.cbAutoRun.Location = new System.Drawing.Point(3, 27);
            this.cbAutoRun.Name = "cbAutoRun";
            this.cbAutoRun.Size = new System.Drawing.Size(240, 16);
            this.cbAutoRun.TabIndex = 5;
            this.cbAutoRun.Text = "当应用程序启动后自动执行列表中的任务";
            this.cbAutoRun.UseVisualStyleBackColor = true;

        }
        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent(TaskListControl taskListControl)
        {
            this.taskListControl = taskListControl;
            this.lblDescription = new System.Windows.Forms.Label();
            this.txtTime = new System.Windows.Forms.TextBox();
            this.lblEndTime = new System.Windows.Forms.Label();
            this.lblTime = new System.Windows.Forms.Label();
            this.cbAutoRun = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // taskListControl
            // 
            this.taskListControl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.taskListControl.Location = new System.Drawing.Point(4, 49);
            this.taskListControl.Name = "taskListControl";
            this.taskListControl.Size = new System.Drawing.Size(747, 477);
            this.taskListControl.TabIndex = 0;
            // 
            // lblDescription
            // 
            this.lblDescription.AutoSize = true;
            this.lblDescription.Location = new System.Drawing.Point(3, 3);
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.Size = new System.Drawing.Size(101, 12);
            this.lblDescription.TabIndex = 1;
            this.lblDescription.Text = "在以下时间执行：";
            // 
            // txtTime
            // 
            this.txtTime.Location = new System.Drawing.Point(110, 0);
            this.txtTime.Name = "txtTime";
            this.txtTime.Size = new System.Drawing.Size(150, 21);
            this.txtTime.TabIndex = 2;
            // 
            // lblEndTime
            // 
            this.lblEndTime.AutoSize = true;
            this.lblEndTime.Location = new System.Drawing.Point(303, 3);
            this.lblEndTime.Name = "lblEndTime";
            this.lblEndTime.Size = new System.Drawing.Size(101, 12);
            this.lblEndTime.TabIndex = 3;
            this.lblEndTime.Text = "离下次执行还有：";
            // 
            // lblTime
            // 
            this.lblTime.AutoSize = true;
            this.lblTime.Location = new System.Drawing.Point(410, 3);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(0, 12);
            this.lblTime.TabIndex = 4;
            // 
            // cbAutoRun
            // 
            this.cbAutoRun.AutoSize = true;
            this.cbAutoRun.Location = new System.Drawing.Point(3, 27);
            this.cbAutoRun.Name = "cbAutoRun";
            this.cbAutoRun.Size = new System.Drawing.Size(240, 16);
            this.cbAutoRun.TabIndex = 5;
            this.cbAutoRun.Text = "当应用程序启动后自动执行列表中的任务";
            this.cbAutoRun.UseVisualStyleBackColor = true;
            this.cbAutoRun.CheckedChanged += new System.EventHandler(this.cbAutoRun_CheckedChanged);
            // 
            // ScheduledItemControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.cbAutoRun);
            this.Controls.Add(this.lblTime);
            this.Controls.Add(this.lblEndTime);
            this.Controls.Add(this.txtTime);
            this.Controls.Add(this.lblDescription);
            this.Controls.Add(this.taskListControl);
            this.Name = "ScheduledItemControl";
            this.Size = new System.Drawing.Size(751, 526);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TaskListControl taskListControl;
        private System.Windows.Forms.Label lblDescription;
        private System.Windows.Forms.TextBox txtTime;
        private System.Windows.Forms.Label lblEndTime;
        private System.Windows.Forms.Label lblTime;
        private System.Windows.Forms.CheckBox cbAutoRun;
    }
}
