﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Reflector.PowerShell")]
[assembly: AssemblyDescription("PowerShell language add-in for Reflector")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("mailto:kzu.net@gmail.com")]
[assembly: AssemblyProduct("Reflector.PowerShell")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("be0bbf1d-c475-4df2-af16-ce8f81f4a701")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
