﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using BaseProvider;
using System.Xml;
using System.Threading;

namespace DynamicLoad
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, IBaseJob> runningJobList = GetJobList();
            Console.ForegroundColor = ConsoleColor.Green;
            Show(" Please input the job name which you want to do,\r\n Input 'C' can get the last version job.");
            Console.ResetColor();
            while (true)
            {
                try
                {
                    string content = Console.ReadLine().ToLower();

                    if (content.ToLower() == "c")
                    {
                        Console.ForegroundColor = ConsoleColor.Magenta;
                        Show("Compare Started,Job count: " + runningJobList.Count);
                        runningJobList = GetJobList();
                        Show("Compare Completed,Job count: " + runningJobList.Count);
                        Console.ResetColor();
                    }
                    else
                    {
                        if (content.Length >= 2)
                        {
                            DoJob(content, runningJobList, new Random().Next());
                        }
                    }
                }
                catch (Exception e)
                {
                    Show(e.Message);
                }
                Thread.Sleep(1000);
            }
        }

        static Dictionary<string, IBaseJob> GetJobList()
        {
            Dictionary<string, string> dictJobs = LoadXML();
            Dictionary<string, IBaseJob> jobList = new Dictionary<string, IBaseJob>();
            IBaseJob baseJob = null;
                foreach (string key in dictJobs.Keys)
                {
                    baseJob = LoadAssembly(key, dictJobs[key]);
                    if (baseJob != null)
                    {
                        jobList.Add(key.Replace("JobProvider", "").ToLower(), baseJob);
                    }
                }
            return jobList;
        }

        static Dictionary<string, string> LoadXML()
        {
            Dictionary<string, string> dictJobs = new Dictionary<string, string>();
            XmlDocument xml = new XmlDocument();
            xml.Load("ProviderConfig.xml");
            XmlNodeList xmlList = xml.SelectNodes("ProviderInformation");
            foreach (XmlNode node in xmlList)
            {
                XmlNodeList childNodes = node.ChildNodes;
                foreach (XmlNode childNode in childNodes)
                {
                    dictJobs.Add(childNode.ChildNodes[0].InnerXml, childNode.ChildNodes[1].InnerXml);
                }
            }
            return dictJobs;
        }

        static IBaseJob LoadAssembly(string ddlName, string className)
        {
            IBaseJob baseJob = null;
            Assembly jobAssembly = null;
            jobAssembly = Assembly.Load(ddlName);
            if (jobAssembly != null)
            {
                object tmpobj = jobAssembly.CreateInstance(className);
                if (tmpobj != null && tmpobj is IBaseJob)
                {
                    baseJob = tmpobj as IBaseJob;
                }
            }
            return baseJob;
        }

        static void DoJob(string key, Dictionary<string, IBaseJob> runningJobList, object objPara)
        {
            try
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Show(runningJobList[key].DoTempJob(objPara).ToString());
                Console.ResetColor();
            }
            catch (KeyNotFoundException)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Show("The job '" + key + "' you want not exsit in job list.");
                Console.ResetColor();
            }
            catch (Exception e)
            {
                throw e;
            }

        }

        static void Show(string information)
        {
            Console.WriteLine(information);
        }
    }
}