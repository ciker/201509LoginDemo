﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BaseProvider
{
    public interface IBaseJob
    {
        Queue<string> privateQueue { get; set; }

        void DoJob(object jobPatameter);

        string DoTempJob(object jobPatameter);
    }
}
