namespace Bootstrap.Tests.Extensions.TestImplementations
{
    public interface ITestInterface {}
}