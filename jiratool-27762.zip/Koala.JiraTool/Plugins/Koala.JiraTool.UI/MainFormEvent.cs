﻿using Framework;

namespace Koala.JiraTool.UI
{
    internal class MainFormEvent : IMainFormEvent
    {
        private readonly ITabController _tabController;

        public MainFormEvent(ITabController tabController)
        {
            _tabController = tabController;
        }

        #region Implementation of IMainFormEvent

        /// <summary>
        /// 主窗体加载完毕。
        /// </summary>
        public void LoadOk()
        {
            _tabController.OpenTab("Koala Framework", tabPage => tabPage.Controls.Add(new InfoControl()));
        }

        #endregion Implementation of IMainFormEvent
    }
}