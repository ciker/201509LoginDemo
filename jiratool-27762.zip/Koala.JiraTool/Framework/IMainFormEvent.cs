﻿using Koala.Framework;

namespace Framework
{
    /// <summary>
    /// 主窗体事件。
    /// </summary>
    public interface IMainFormEvent : IDependency
    {
        /// <summary>
        /// 主窗体加载完毕。
        /// </summary>
        void LoadOk();
    }
}