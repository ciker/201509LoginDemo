﻿using System.Windows.Forms;

namespace Koala.JiraTool.UI
{
    public partial class InfoControl : UserControl
    {
        public InfoControl()
        {
            InitializeComponent();
            richTextBox.Text = Resources.Content;
        }
    }
}