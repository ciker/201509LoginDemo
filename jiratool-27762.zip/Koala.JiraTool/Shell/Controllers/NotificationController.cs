﻿using Framework;
using System.Windows.Forms;

namespace Shell.Controllers
{
    internal class NotificationController : INotificationController
    {
        #region Implementation of INotificationController

        public void Message(string format, params object[] args)
        {
            var tsslMessage = MainForm.ToolStripItem;
            var notifyIcon = MainForm.NotifyIcon;
            string text;
            if (args == null)
            {
                text = format;
            }
            else
            {
                text = string.Format(format, args);
            }
            tsslMessage.Text = text;
            notifyIcon.ShowBalloonTip(1000, "提示", text, ToolTipIcon.Info);
        }

        #endregion Implementation of INotificationController
    }
}