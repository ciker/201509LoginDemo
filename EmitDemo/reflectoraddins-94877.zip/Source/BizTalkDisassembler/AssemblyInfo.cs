﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("BizTalk Server 2006 Artifact Disassembler for Lutz Roeder's Reflector.")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Microsoft, Corp.")]
[assembly: AssemblyProduct("Reflector.BizTalkDisassembler")]
[assembly: AssemblyCopyright("Copyright © Microsoft, Corp. 2006")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// We are CLS compliant
[assembly: CLSCompliant(true)]

// Assembly not COM visible
[assembly: ComVisible(false)]

// Version information
[assembly: AssemblyVersion("1.0.0.1")]
[assembly: AssemblyFileVersion("1.0.0.1")]
