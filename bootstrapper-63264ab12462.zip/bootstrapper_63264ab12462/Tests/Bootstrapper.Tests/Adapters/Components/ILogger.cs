namespace Bootstrap.Tests.Adapters.Components
{
	public interface ILogger
	{
		void Log(string msg);
	}
}