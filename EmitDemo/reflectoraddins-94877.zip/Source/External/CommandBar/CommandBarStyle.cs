// ---------------------------------------------------------
// Windows Forms CommandBar Control
// Copyright (C) 2001-2003 Lutz Roeder. All rights reserved.
// http://www.aisto.com/roeder
// ---------------------------------------------------------
namespace System.Windows.Forms
{
	public enum CommandBarStyle
	{
		Menu,
		ToolBar
	}
	
}
