﻿namespace Koala.JiraTool.TaskList.Dialog
{
    partial class ResolveTaskDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ResolveTaskDialog));
            this.lblResolveResult = new System.Windows.Forms.Label();
            this.cmbResolveResult = new System.Windows.Forms.ComboBox();
            this.txtConsumeTime = new System.Windows.Forms.TextBox();
            this.lblConsumeTime = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.rbAuto = new System.Windows.Forms.RadioButton();
            this.lblSurplus = new System.Windows.Forms.Label();
            this.lblEnvironment = new System.Windows.Forms.Label();
            this.lblRemark = new System.Windows.Forms.Label();
            this.txtEnvironment = new System.Windows.Forms.TextBox();
            this.txtRemark = new System.Windows.Forms.TextBox();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tsbSave = new System.Windows.Forms.ToolStripButton();
            this.lblStarterTime = new System.Windows.Forms.Label();
            this.txtStartTime = new System.Windows.Forms.TextBox();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblResolveResult
            // 
            this.lblResolveResult.AutoSize = true;
            this.lblResolveResult.Location = new System.Drawing.Point(39, 39);
            this.lblResolveResult.Name = "lblResolveResult";
            this.lblResolveResult.Size = new System.Drawing.Size(65, 12);
            this.lblResolveResult.TabIndex = 0;
            this.lblResolveResult.Text = "解决结果：";
            // 
            // cmbResolveResult
            // 
            this.cmbResolveResult.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbResolveResult.FormattingEnabled = true;
            this.cmbResolveResult.Items.AddRange(new object[] {
            "未解决",
            "已解决",
            "未分配",
            "问题重复",
            "部分解决",
            "信息不足"});
            this.cmbResolveResult.Location = new System.Drawing.Point(110, 36);
            this.cmbResolveResult.Name = "cmbResolveResult";
            this.cmbResolveResult.Size = new System.Drawing.Size(162, 20);
            this.cmbResolveResult.TabIndex = 1;
            // 
            // txtConsumeTime
            // 
            this.txtConsumeTime.Location = new System.Drawing.Point(110, 62);
            this.txtConsumeTime.Name = "txtConsumeTime";
            this.txtConsumeTime.Size = new System.Drawing.Size(162, 21);
            this.txtConsumeTime.TabIndex = 2;
            // 
            // lblConsumeTime
            // 
            this.lblConsumeTime.AutoSize = true;
            this.lblConsumeTime.Location = new System.Drawing.Point(39, 65);
            this.lblConsumeTime.Name = "lblConsumeTime";
            this.lblConsumeTime.Size = new System.Drawing.Size(65, 12);
            this.lblConsumeTime.TabIndex = 3;
            this.lblConsumeTime.Text = "消耗时间：";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(278, 65);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 12);
            this.label1.TabIndex = 4;
            this.label1.Text = "例如. 3w 4d 12h";
            // 
            // rbAuto
            // 
            this.rbAuto.AutoSize = true;
            this.rbAuto.Checked = true;
            this.rbAuto.Location = new System.Drawing.Point(110, 96);
            this.rbAuto.Name = "rbAuto";
            this.rbAuto.Size = new System.Drawing.Size(71, 16);
            this.rbAuto.TabIndex = 5;
            this.rbAuto.TabStop = true;
            this.rbAuto.Text = "自动调整";
            this.rbAuto.UseVisualStyleBackColor = true;
            // 
            // lblSurplus
            // 
            this.lblSurplus.AutoSize = true;
            this.lblSurplus.Location = new System.Drawing.Point(39, 98);
            this.lblSurplus.Name = "lblSurplus";
            this.lblSurplus.Size = new System.Drawing.Size(65, 12);
            this.lblSurplus.TabIndex = 6;
            this.lblSurplus.Text = "剩余时间：";
            // 
            // lblEnvironment
            // 
            this.lblEnvironment.AutoSize = true;
            this.lblEnvironment.Location = new System.Drawing.Point(63, 172);
            this.lblEnvironment.Name = "lblEnvironment";
            this.lblEnvironment.Size = new System.Drawing.Size(41, 12);
            this.lblEnvironment.TabIndex = 7;
            this.lblEnvironment.Text = "环境：";
            // 
            // lblRemark
            // 
            this.lblRemark.AutoSize = true;
            this.lblRemark.Location = new System.Drawing.Point(63, 267);
            this.lblRemark.Name = "lblRemark";
            this.lblRemark.Size = new System.Drawing.Size(41, 12);
            this.lblRemark.TabIndex = 8;
            this.lblRemark.Text = "备注：";
            // 
            // txtEnvironment
            // 
            this.txtEnvironment.Location = new System.Drawing.Point(110, 169);
            this.txtEnvironment.Multiline = true;
            this.txtEnvironment.Name = "txtEnvironment";
            this.txtEnvironment.Size = new System.Drawing.Size(425, 74);
            this.txtEnvironment.TabIndex = 9;
            // 
            // txtRemark
            // 
            this.txtRemark.Location = new System.Drawing.Point(110, 264);
            this.txtRemark.Multiline = true;
            this.txtRemark.Name = "txtRemark";
            this.txtRemark.Size = new System.Drawing.Size(425, 110);
            this.txtRemark.TabIndex = 10;
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbSave});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(571, 25);
            this.toolStrip1.TabIndex = 11;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // tsbSave
            // 
            this.tsbSave.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbSave.Image = ((System.Drawing.Image)(resources.GetObject("tsbSave.Image")));
            this.tsbSave.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbSave.Name = "tsbSave";
            this.tsbSave.Size = new System.Drawing.Size(50, 22);
            this.tsbSave.Text = "保存[&S]";
            this.tsbSave.Click += new System.EventHandler(this.tsbSave_Click);
            // 
            // lblStarterTime
            // 
            this.lblStarterTime.AutoSize = true;
            this.lblStarterTime.Location = new System.Drawing.Point(39, 128);
            this.lblStarterTime.Name = "lblStarterTime";
            this.lblStarterTime.Size = new System.Drawing.Size(65, 12);
            this.lblStarterTime.TabIndex = 12;
            this.lblStarterTime.Text = "开始日期：";
            // 
            // txtStartTime
            // 
            this.txtStartTime.Location = new System.Drawing.Point(110, 125);
            this.txtStartTime.Name = "txtStartTime";
            this.txtStartTime.Size = new System.Drawing.Size(162, 21);
            this.txtStartTime.TabIndex = 13;
            // 
            // ResolveTaskDialog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(571, 386);
            this.Controls.Add(this.txtStartTime);
            this.Controls.Add(this.lblStarterTime);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.txtRemark);
            this.Controls.Add(this.txtEnvironment);
            this.Controls.Add(this.lblRemark);
            this.Controls.Add(this.lblEnvironment);
            this.Controls.Add(this.lblSurplus);
            this.Controls.Add(this.rbAuto);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblConsumeTime);
            this.Controls.Add(this.txtConsumeTime);
            this.Controls.Add(this.cmbResolveResult);
            this.Controls.Add(this.lblResolveResult);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ResolveTaskDialog";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "解决问题";
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblResolveResult;
        private System.Windows.Forms.ComboBox cmbResolveResult;
        private System.Windows.Forms.TextBox txtConsumeTime;
        private System.Windows.Forms.Label lblConsumeTime;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton rbAuto;
        private System.Windows.Forms.Label lblSurplus;
        private System.Windows.Forms.Label lblEnvironment;
        private System.Windows.Forms.Label lblRemark;
        private System.Windows.Forms.TextBox txtEnvironment;
        private System.Windows.Forms.TextBox txtRemark;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton tsbSave;
        private System.Windows.Forms.Label lblStarterTime;
        private System.Windows.Forms.TextBox txtStartTime;
    }
}