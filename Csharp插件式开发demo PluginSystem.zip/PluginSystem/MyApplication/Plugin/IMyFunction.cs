﻿namespace Plugin
{
    public interface IMyFunction
    {
        void doSomething();
    }
}
