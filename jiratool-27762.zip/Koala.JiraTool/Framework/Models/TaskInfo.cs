﻿using System;

namespace Framework.Models
{
    /// <summary>
    /// 任务信息。
    /// </summary>
    public class TaskInfo
    {
        /// <summary>
        /// 任务Id。
        /// </summary>
        public string Id { get; set; }

        /// <summary>
        /// 关键字。
        /// </summary>
        public string Keyword { get; set; }

        /// <summary>
        /// 主题。
        /// </summary>
        public string Topic { get; set; }

        /// <summary>
        /// 经办人。
        /// </summary>
        public string User { get; set; }

        /// <summary>
        /// 报告人。
        /// </summary>
        public string Speaker { get; set; }

        /// <summary>
        /// 优先级。
        /// </summary>
        public string Priority { get; set; }

        /// <summary>
        /// 状态。
        /// </summary>
        public string Status { get; set; }

        /// <summary>
        /// 创建时间。
        /// </summary>
        public DateTime? CreateDateTime { get; set; }

        /// <summary>
        /// 更新时间。
        /// </summary>
        public DateTime? UpdateDateTime { get; set; }

        /// <summary>
        /// 到期时间。
        /// </summary>
        public DateTime? ExpireDateTime { get; set; }

        /*/// <summary>
        /// 任务类型。
        /// </summary>
        public TaskType TaskType { get; set; }*/

        /// <summary>
        /// 任务类型字符串。
        /// </summary>
        public string TaskType { get; set; }
    }
}