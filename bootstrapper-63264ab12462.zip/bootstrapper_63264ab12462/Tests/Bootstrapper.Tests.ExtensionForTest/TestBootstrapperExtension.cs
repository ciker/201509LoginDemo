﻿using System;
using Bootstrap.Extensions;

namespace Bootstrap.Tests.ExtensionForTest
{
    public class TestBootstrapperExtension: IBootstrapperExtension
    {
        public void Run()
        {
            throw new NotImplementedException();
        }

        public void Reset()
        {
            throw new NotImplementedException();
        }
    }
}
