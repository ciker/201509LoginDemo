﻿using SimplePlugin.PluginCore;

namespace SimplePlugin.SimpleMvcPlugin
{
    public class SimpleMvcPlugin : IPlugin
    {
    }
}