﻿namespace SimplePlugin.PluginCore
{
    public interface IPlugin
    {
    }
}