﻿using System.Text;

namespace Framework
{
    public class GlobalSettings
    {
        public string RootUrl { get; set; }

        public string LoginUrl { get; set; }

        /// <summary>
        /// {0}：TaskId，{1}：Token。
        /// </summary>
        public string StartTaskUrlFormat { get; set; }

        /// <summary>
        /// {0}：TaskId，{1}：Token。
        /// </summary>
        public string StopTaskUrlFormat { get; set; }

        /// <summary>
        /// {0}：Token
        /// </summary>
        public string ResolveTaskUrlFormat { get; set; }

        public Encoding Encoding { get; set; }

        /// <summary>
        /// {0}：JQL
        /// </summary>
        public string SearchTaskUrlFormat { get; set; }

        /// <summary>
        /// {0}：Keyword。
        /// </summary>
        public string TaskViewUrlFormat { get; set; }
    }
}