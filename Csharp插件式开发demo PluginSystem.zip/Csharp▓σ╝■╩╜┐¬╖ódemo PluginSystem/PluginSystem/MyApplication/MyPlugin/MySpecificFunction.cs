﻿using System.Windows.Forms;
using Plugin;

namespace MyPlugin
{
    public class MySpecificFunction : IMyFunction
    {
        public MySpecificFunction()
        {
        }
        public void doSomething()
        {
            MessageBox.Show("我是插件执行的结果");
        }
    }
}
