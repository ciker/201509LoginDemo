using System;
using System.Collections.Generic;
using System.Text;

using Castle.Windsor;
using Common.Logging;
using Quartz;
using Castle.Facilities.Startable;
using Quartz.Impl;
using System.Threading;

namespace QuartzComponent
{
    class ConsoleMain
    {
       static  ILog log = LogManager.GetLogger(typeof(ConsoleMain));

        [STAThread]
        public static void Main(string[] args)
        {
            IWindsorContainer container = new WindsorContainer();
            //����Facility

            container.AddFacility("startable", new StartableFacility());

            container.AddComponent("Scheduler", typeof(ISchedulerFactory), typeof(StdSchedulerFactory));

            container.AddComponent("QuartzStartable", typeof(QuartzStartable));
                       
            //Console.Read();
        }
    }
}
