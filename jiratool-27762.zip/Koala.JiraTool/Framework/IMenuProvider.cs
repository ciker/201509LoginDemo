﻿using System.Collections.Generic;
using Framework.Models;
using Koala.Framework;

namespace Framework
{
    public interface IMenuProvider : IDependency
    {
        void GetMenuList(List<MenuInfo> menuInfos);
    }
}