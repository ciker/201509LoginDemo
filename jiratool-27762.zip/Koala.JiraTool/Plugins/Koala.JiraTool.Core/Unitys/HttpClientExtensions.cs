﻿using Framework;
using HtmlAgilityPack;

namespace Koala.JiraTool.Core.Unitys
{
    internal static class HttpClientExtensions
    {
        public static HtmlNode DownloadDocumentNode(this IHttpClient httpClient, string address)
        {
            var document = new HtmlDocument();
            var html = httpClient.DownloadString(address);
            document.LoadHtml(html);
            return document.DocumentNode;
        }
    }
}