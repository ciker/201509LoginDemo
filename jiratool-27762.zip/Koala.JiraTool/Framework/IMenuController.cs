﻿using Framework.Models;
using Koala.Framework;

namespace Framework
{
    public interface IMenuController : IDependency
    {
        void AddMenu(MenuInfo menuInfo);
    }
}