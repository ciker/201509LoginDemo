﻿namespace Bootstrap.Tests.Extensions.TestImplementations
{
    public class RegisteredByConvention: IRegisteredByConvention
    {
        public void DoSomething() {}
    }
}
