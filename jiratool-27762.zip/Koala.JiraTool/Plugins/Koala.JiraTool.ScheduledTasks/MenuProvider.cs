﻿using Framework;
using Framework.Models;
using Koala.JiraTool.ScheduledTasks.Controls;
using System;
using System.Collections.Generic;

namespace Koala.JiraTool.ScheduledTasks
{
    internal class MenuProvider : IMenuProvider
    {
        private readonly Lazy<MainFormControl> _mainFormControl;
        private readonly ITabController _tabController;
        private readonly ILoginController _loginController;
        private readonly INotificationController _notificationController;

        public MenuProvider(Lazy<MainFormControl> mainFormControl, ITabController tabController, ILoginController loginController, INotificationController notificationController)
        {
            _mainFormControl = mainFormControl;
            _tabController = tabController;
            _loginController = loginController;
            _notificationController = notificationController;
        }

        #region Implementation of IMenuProvider

        public void GetMenuList(List<MenuInfo> menuInfos)
        {
            var menuInfo = new MenuInfo { Text = "计划任务" };
            menuInfo.Click += (s, e) =>
                {
                    if (!_loginController.IsLogin())
                    {
                        _notificationController.Message("请先登录.......");
                        return;
                    }
                    _tabController.OpenTab("计划任务", tabPage =>
                        {
                            var mainFormControl = _mainFormControl.Value;
                            tabPage.Controls.Add(mainFormControl);
                        });
                };
            menuInfos.Add(menuInfo);
        }

        #endregion Implementation of IMenuProvider
    }
}