﻿using Framework.Models;
using Koala.Framework;
using System.Collections.Generic;

namespace Framework
{
    /// <summary>
    /// 任务控制器。
    /// </summary>
    public interface ITaskController : ITransientDependency
    {
        /// <summary>
        /// 根据任务类型获取任务集合。
        /// </summary>
        /// <param name="taskTypes">任务类型。</param>
        /// <returns>任务集合。</returns>
        IList<TaskInfo> GetTaskList(params string[] taskTypes);

        /// <summary>
        /// 根据任务状态获取任务集合。
        /// </summary>
        /// <param name="taskStatus">任务状态。</param>
        /// <returns>任务集合。</returns>
        IList<TaskInfo> GetTaskListByStatus(params string[] taskStatus);

        /// <summary>
        /// 根据项目名称和任务类型获取任务集合。
        /// </summary>
        /// <param name="projectNames">项目名称。</param>
        /// <param name="taskTypes">任务类型。</param>
        /// <returns>任务集合。</returns>
        IList<TaskInfo> GetTaskListByProjectName(string[] projectNames, params string[] taskTypes);

        /// <summary>
        /// 解决问题。
        /// </summary>
        /// <param name="resolveTaskInfo">解决问题信息。</param>
        void ResolveTask(ResolveTaskInfo resolveTaskInfo);

        /// <summary>
        /// 根据关键字获取任务信息。
        /// </summary>
        /// <param name="keyword">关键字。</param>
        /// <returns>任务信息。</returns>
        TaskInfo GetTask(string keyword);

        /// <summary>
        /// 停止任务。
        /// </summary>
        /// <param name="taskId">任务Id。</param>
        void StopTask(string taskId);

        /// <summary>
        /// 启动任务。
        /// </summary>
        /// <param name="taskId">任务Id。</param>
        void StartTask(string taskId);

        /// <summary>
        /// 停止任务。
        /// </summary>
        /// <param name="taskId">任务Id。</param>
        /// <param name="keyword">关键字。</param>
        /// <returns>是否停止成功。</returns>
        bool StopTask(string taskId, string keyword);

        /// <summary>
        /// 启动任务。
        /// </summary>
        /// <param name="taskId">任务Id。</param>
        /// <param name="keyword">关键字。</param>
        /// <returns>是否启用成功。</returns>
        bool StartTask(string taskId, string keyword);
    }
}