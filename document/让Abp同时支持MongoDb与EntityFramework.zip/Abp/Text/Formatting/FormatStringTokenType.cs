namespace Abp.Text.Formatting
{
    internal enum FormatStringTokenType
    {
        ConstantText,
        DynamicValue
    }
}