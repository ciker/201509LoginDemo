namespace Abp.Runtime.Validation
{
    /// <summary>
    /// This interface is implemented by classes those are needed to validate before use.
    /// </summary>
    public interface IValidate
    {
        
    }
}