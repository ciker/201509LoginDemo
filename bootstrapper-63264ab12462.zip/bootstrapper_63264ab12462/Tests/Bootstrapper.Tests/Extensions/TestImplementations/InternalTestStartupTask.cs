﻿using Bootstrap.Extensions.StartupTasks;

namespace Bootstrap.Tests.Extensions.TestImplementations
{
    internal class InternalTestStartupTask : IStartupTask
    {
        public void Run() { }
        public void Reset() { }
    }
}