﻿using Framework;
using Framework.Models;
using Koala.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace Koala.JiraTool.ScheduledTasks.Controls
{
    public partial class MainFormControl : UserControl, IDependency
    {
        private readonly ITaskController _taskController;
        private readonly IDataPersistence _dataPersistence;
        private readonly INotificationController _notificationController;

        #region Constructor

        public MainFormControl(ITaskController taskController, IContainer container, IDataPersistence dataPersistence, INotificationController notificationController)
        {
            _taskController = taskController;
            _dataPersistence = dataPersistence;
            _notificationController = notificationController;
            if (DesignMode)
            {
                InitializeComponent();
            }
            else
            {
                InitializeComponent(container);
            }
            var status = new[] { "开启", "处理中", "重启" };
            var startSettings = _dataPersistence.Get<ScheduledItemSettings>(sicStart.Name + "_Settings");
            var endSettings = _dataPersistence.Get<ScheduledItemSettings>(sicStop.Name + "_Settings");
            if (startSettings == null)
            {
                startSettings = new ScheduledItemSettings
                {
                    StartAutoRun = true,
                    Time = "9:00,13:50"
                };
            }
            if (endSettings == null)
            {
                endSettings = new ScheduledItemSettings
                {
                    StartAutoRun = false,
                    Time = "14:40,17:55"
                };
            }
            sicStart.SetControl(startSettings, status);
            sicStop.SetControl(endSettings, status);
            sicStart.TaskRun += sicStart_TaskRun;
            sicStop.TaskRun += sicStop_TaskRun;
        }

        private void sicStop_TaskRun(IList<TaskInfo> taskInfos)
        {
            TaskRun(taskInfos, false);
            _notificationController.Message("停止列表任务执行完成。");
        }

        private void sicStart_TaskRun(IList<TaskInfo> taskInfos)
        {
            TaskRun(taskInfos, true);
            _notificationController.Message("启动列表任务执行完成。");
        }

        #endregion Constructor

        #region Event

        private void tsbStart_Click(object sender, EventArgs e)
        {
            var tab = tabControl.SelectedTab;
            HandleScheduled(true, tab.TabIndex == tpStartTask.TabIndex ? sicStart : sicStop);
        }

        private void tsbStop_Click(object sender, EventArgs e)
        {
            var tab = tabControl.SelectedTab;
            HandleScheduled(false, tab.TabIndex == tpStartTask.TabIndex ? sicStart : sicStop);
        }

        private void tsbAllStart_Click(object sender, EventArgs e)
        {
            HandleScheduled(true, sicStart, sicStop);
        }

        private void tsbAllStop_Click(object sender, EventArgs e)
        {
            HandleScheduled(false, sicStart, sicStop);
        }

        #endregion Event

        #region Private Method

        private void TaskRun(IList<TaskInfo> taskInfos, bool isStart)
        {
            if (taskInfos == null || !taskInfos.Any())
                return;
            taskInfos = taskInfos.Where(model => model != null && !string.IsNullOrWhiteSpace(model.Id)).ToList();
            foreach (var taskInfo in taskInfos)
            {
                if (isStart)
                    _taskController.StartTask(taskInfo.Id);
                else
                    _taskController.StopTask(taskInfo.Id);
            }
        }

        private static void HandleScheduled(bool isStart, params  ScheduledItemControl[] scheduledItemControls)
        {
            foreach (var scheduledItemControl in scheduledItemControls)
            {
                if (isStart)
                    scheduledItemControl.Run();
                else
                    scheduledItemControl.Stop();
            }
        }

        #endregion Private Method
    }
}