﻿using Framework;

namespace Koala.JiraTool.TaskList
{
    internal class MainFormEvent : IMainFormEvent
    {
        private readonly ITabController _tabController;
        private readonly MainFormControl _mainFormControl;

        public MainFormEvent(ITabController tabController, MainFormControl mainFormControl)
        {
            _tabController = tabController;
            _mainFormControl = mainFormControl;
        }

        #region Implementation of IMainFormEvent

        /// <summary>
        /// 主窗体加载完毕。
        /// </summary>
        public void LoadOk()
        {
            _tabController.OpenTab("任务列表", tabPage => tabPage.Controls.Add(_mainFormControl), false);
        }

        #endregion Implementation of IMainFormEvent
    }
}