var App = {
	Models : {},
	Routers : {},
	Collections : {},
	Views : {}
};

