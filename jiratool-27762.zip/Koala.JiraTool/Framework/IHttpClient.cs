﻿using System.Collections.Specialized;
using Koala.Framework;

namespace Framework
{
    public interface IHttpClient : IDependency
    {
        string PostData(string address, NameValueCollection postData);

        string DownloadString(string address);

        void Reset();
    }
}