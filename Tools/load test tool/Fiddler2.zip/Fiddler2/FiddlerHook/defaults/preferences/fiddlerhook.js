pref("extensions.fiddlerhook.hookmode", 0);
pref("extensions.fiddlerhook.bypasslist", "");

pref("extensions.fiddlerhook.backup-no_proxies_on", "");
pref("extensions.fiddlerhook.backup-proxytype", 0);
pref("extensions.fiddlerhook.backup-proxyhttphost", "");
pref("extensions.fiddlerhook.backup-proxyhttpport", 0);
pref("extensions.fiddlerhook.backup-proxysslhost", "");
pref("extensions.fiddlerhook.backup-proxysslport", 0);
pref("extensions.fiddlerhook.backup-no_proxies_on", "");

// See http://kb.mozillazine.org/Localize_extension_descriptions
pref("extensions.fiddlerhook@fiddler2.com.description", "chrome://fiddlerhook/locale/fiddlerhook.properties");