# slimgotest
The example of slimgo & slimmysql.
