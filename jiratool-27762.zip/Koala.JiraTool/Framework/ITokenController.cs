﻿using Koala.Framework;

namespace Framework
{
    /// <summary>
    /// Token控制器。
    /// </summary>
    public interface ITokenController : ITransientDependency
    {
        /// <summary>
        /// 获取当前上下文的Token。
        /// </summary>
        /// <returns>Token。</returns>
        string GetToken();
    }
}