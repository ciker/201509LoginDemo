﻿using Koala.Framework;

namespace Framework
{
    public interface IMainForm : IDependency
    {
    }
}