﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Reflector.UmlExporter")]
[assembly: AssemblyProduct("Reflector.UmlExporter")]
[assembly: AssemblyDescription("A .NET Reflector add-in that allows you to export an assembly to XMI.")]
[assembly: AssemblyConfiguration("RELEASE")]
[assembly: AssemblyCompany("Swinburne University")]
[assembly: AssemblyCopyright("Copyright \x0A9 2006 Swinburne University")]

[assembly: ComVisible(false)]
[assembly: Guid("ff3959b5-3819-45fb-aca6-3ae4691690b6")]

[assembly: AssemblyVersion("0.1.0.*")]
[assembly: AssemblyFileVersion("0.1.0.0")]
