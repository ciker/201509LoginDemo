﻿using Koala.Framework;

namespace Framework
{
    /// <summary>
    /// 登录控制器。
    /// </summary>
    public interface ILoginController : ITransientDependency
    {
        /// <summary>
        /// 判断当前登录状态。
        /// </summary>
        /// <returns>Ture为已登录，False则未登录。</returns>
        bool IsLogin();

        /// <summary>
        /// 登录。
        /// </summary>
        /// <param name="userName">用户名。</param>
        /// <param name="password">密码。</param>
        /// <param name="message">登录过程中产生的信息。</param>
        /// <returns>Ture为登录成功，False为登录失败。</returns>
        bool Login(string userName, string password, out string message);

        /// <summary>
        /// 登出。
        /// </summary>
        /// <returns>Ture为登出成功，False为登出失败。</returns>
        bool Logout();

        /// <summary>
        /// 获取真实用户名。
        /// </summary>
        string GetUserName();
    }
}