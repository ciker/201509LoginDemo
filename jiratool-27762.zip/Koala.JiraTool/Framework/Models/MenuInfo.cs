﻿using System;

namespace Framework.Models
{
    public class MenuInfo
    {
        public MenuInfo()
        {
            IsClose = true;
        }

        public string Text { get; set; }

        public bool IsClose { get; set; }

        public MenuInfo[] ChildMenus { get; set; }

        public EventHandler ClickEventHandler
        {
            get { return _clickEventHandler; }
            private set { _clickEventHandler = value; }
        }

        private EventHandler _clickEventHandler = (s, e) => { };

        public event EventHandler Click
        {
            add
            {
                ClickEventHandler += value;
            }
            remove { ClickEventHandler -= value; }
        }
    }
}