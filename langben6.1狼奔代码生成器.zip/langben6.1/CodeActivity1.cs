﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Activities;

using DAL;
namespace WFActivitys
{
    /// <summary>
    /// 活动
    /// </summary>
    public sealed class CodeActivity1 : NativeActivity
    {

        /// <summary>
        /// 输入输出的参数
        /// </summary>
        public InArgument<^ReplaceClassCode^> My { get; set; }
        /// <summary>
        /// 标签名称
        /// </summary>
        public string BookmarkName { get; set; }

        /// <summary>
        /// 执行
        /// </summary>
        /// <param name="context">上下文</param>
        protected override void Execute(NativeActivityContext context)
        {
            string state = "^ReplaceAttribute^";
            SysEntities db = new SysEntities();
            ^ReplaceClassCode^ my = My.Get(context);
            var entity = db.^ReplaceClassCode^.SingleOrDefault(s => s.^m_Id^ == my.^m_Id^);
            entity.^State^ = state;
            entity.WF = context.WorkflowInstanceId.ToString();//工作流的唯一标识
            db.SaveChanges();
            context.CreateBookmark(BookmarkName, new BookmarkCallback(this.Continue));
        }
        /// <summary>
        /// 回调函数，在恢复标签的时候执行
        /// </summary>
        /// <param name="context">上下文</param>
        /// <param name="bookmark">标签名称</param>
        /// <param name="obj">在恢复标签的时候传入的对象</param>
        void Continue(NativeActivityContext context, Bookmark bookmark,object inputs)
        {
            //输出的参数
            //My.Set(context, inputs);

        }
        /// <summary>
        /// 该值指示活动是否会使工作流进入空闲状态
        /// </summary>
        protected override bool CanInduceIdle { get { return true; } }
    }
}
