﻿using Framework;
using Koala.JiraTool.Login.Controls;

namespace Koala.JiraTool.Login
{
    internal class MainFormEvent : IMainFormEvent
    {
        private readonly ITabController _tabController;
        private readonly LoginControl _loginControl;

        public MainFormEvent(ITabController tabController, LoginControl loginControl)
        {
            _tabController = tabController;
            _loginControl = loginControl;
        }

        #region Implementation of IMainFormEvent

        /// <summary>
        /// 主窗体加载完毕。
        /// </summary>
        public void LoadOk()
        {
            _tabController.OpenTab("用户登录", tabPage => tabPage.Controls.Add(_loginControl), false);
        }

        #endregion Implementation of IMainFormEvent
    }
}