﻿namespace Framework.Models
{
    /// <summary>
    /// 解决问题信息。
    /// </summary>
    public class ResolveTaskInfo
    {
        /// <summary>
        /// 解决结果。
        /// <remarks>2：未解决，1：已解决，6：未分配，3:问题重复,4:部分解决，5：信息不足</remarks>
        /// </summary>
        public string ResolveResult { get; set; }

        /// <summary>
        /// 任务Id。
        /// </summary>
        public string TaskId { get; set; }

        /// <summary>
        /// 消耗时间。
        /// </summary>
        public string ConsumeTime { get; set; }

        /// <summary>
        /// 开始时间。
        /// </summary>
        public string StartTime { get; set; }

        /// <summary>
        /// 环境。
        /// </summary>
        public string Environment { get; set; }

        /// <summary>
        /// 备注。
        /// </summary>
        public string Remark { get; set; }
    }
}