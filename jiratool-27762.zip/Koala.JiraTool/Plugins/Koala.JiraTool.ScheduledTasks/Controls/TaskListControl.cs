﻿using Framework;
using Framework.Models;
using Koala.Framework;
using Koala.JiraTool.ScheduledTasks.Controls.Dialog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Koala.JiraTool.ScheduledTasks.Controls
{
    public partial class TaskListControl : UserControl, ITransientDependency
    {
        #region Field

        private readonly List<TaskInfo> _taskInfos = new List<TaskInfo>();
        private readonly IContainer _container;
        private readonly IDataPersistence _dataPersistence;
        private string[] _taskStatus;

        #endregion Field

        #region Constructor

        public TaskListControl()
            : this(null, null)
        {
        }

        public TaskListControl(IContainer container, IDataPersistence dataPersistence)
        {
            _container = container;
            _dataPersistence = dataPersistence;
            InitializeComponent();
            dgvMain.AutoGenerateColumns = false;
        }

        #endregion Constructor

        #region Event

        private void TaskListControl_Load(object sender, EventArgs e)
        {
            if (DesignMode)
                return;
            var list = _dataPersistence.Get<List<TaskInfo>>(Name + "_TaskList");
            _taskInfos.Clear();
            if (list == null) return;
            _taskInfos.AddRange(list);
            DataBind();
        }

        private void tsbAdd_Click(object sender, EventArgs e)
        {
            var addTaskDialog = _container.Resolve<AddTaskDialog>();
            addTaskDialog.Name = Name + "_AddTaskDialog";
            addTaskDialog.LoadControl(_taskStatus);
            var result = addTaskDialog.ShowDialog();
            if (result != DialogResult.OK)
                return;
            var sList = addTaskDialog.GetList();
            var addList = sList.Where(model => _taskInfos.All(m => m.Keyword != model.Keyword));
            _taskInfos.AddRange(addList);
            DataBind();
        }

        private void tsbDel_Click(object sender, EventArgs e)
        {
            var rows = dgvMain.SelectedRows;
            if (rows.Count == 0)
                return;
            foreach (DataGridViewRow row in rows)
            {
                var keyword = row.Cells["Keyword"].Value.ToString();
                var model = _taskInfos.First(m => m.Keyword == keyword);
                _taskInfos.Remove(model);
            }
            DataBind();
        }

        #endregion Event

        #region Public Method

        public void SetTaskStatus(params string[] taskStatus)
        {
            _taskStatus = taskStatus;
        }

        public List<TaskInfo> GetList()
        {
            return _taskInfos;
        }

        public List<TaskInfo> GetSelectList()
        {
            var list = new List<TaskInfo>();
            var rows = dgvMain.SelectedRows;
            if (rows.Count == 0)
                return list;
            foreach (DataGridViewRow row in rows)
            {
                var keyword = row.Cells["Keyword"].Value.ToString();
                var model = _taskInfos.First(m => m.Keyword == keyword);
                list.Add(model);
            }
            return list;
        }

        public void SetDataGridView(List<TaskInfo> taskInfos)
        {
            foreach (var taskInfo in taskInfos)
            {
                var model = _taskInfos.FirstOrDefault(m => m.Id == taskInfo.Id);
                if (model == null)
                    return;
                model.Status = taskInfo.Status;
            }
            DataBind();
        }

        public void SetControl(bool readOnly)
        {
            dgvMain.Enabled = toolStrip.Enabled = readOnly;
        }

        #endregion Public Method

        #region Private Method

        private void DataBind()
        {
            dgvMain.DataSource = null;
            dgvMain.DataSource = _taskInfos;
            Task.Factory.StartNew(() => _dataPersistence.Save(Name + "_TaskList", _taskInfos));
        }

        #endregion Private Method
    }
}