﻿namespace Koala.JiraTool.ScheduledTasks
{
    public class ScheduledItemSettings
    {
        /// <summary>
        /// 时间。
        /// </summary>
        public string Time { get; set; }

        /// <summary>
        /// 启动时候是否自动执行。
        /// </summary>
        public bool StartAutoRun { get; set; }
    }
}