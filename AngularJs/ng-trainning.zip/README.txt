A Pen created at CodePen.io. You can find this one at http://codepen.io/anon/pen/zvpBdB.

 

Forked from [green](http://codepen.io/greengerong/)'s Pen [ng-trainning](http://codepen.io/greengerong/pen/pjwXQW/).