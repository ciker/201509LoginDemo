namespace Bootstrap.Extensions
{
    public interface IBootstrapperExtension
    {
        void Run();
        void Reset();
    }
}